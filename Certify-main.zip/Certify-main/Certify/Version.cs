﻿namespace Certify
{
    public static class Version
    {
        public static string version = "1.1.0";
    }
}
